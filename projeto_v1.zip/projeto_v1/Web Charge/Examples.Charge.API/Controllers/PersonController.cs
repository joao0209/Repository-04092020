﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Examples.Charge.Application.Interfaces;
using Examples.Charge.Application.Messages.Request;
using Examples.Charge.Application.Messages.Response;
using Microsoft.AspNetCore.Mvc;

namespace Examples.Charge.API.Controllers
{
    [Route("api/person")]
    [ApiController]
    public class PersonController : BaseController
    {
        private IPersonFacade _facade;

        public PersonController(IPersonFacade facade, IMapper mapper)
        {
            _facade = facade;
        }

        [HttpGet]
        public async Task<ActionResult<PersonResponse>> Get() => Response(await _facade.FindAllAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<PersonResponse>> GetAsync(int id)
        {
            return Response(await _facade.FindByID(id));
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] PersonRequest request)
        {
            var person = await _facade.PostPerson(request.Nome);

            return Response(person.PersonObjects.FirstOrDefault().BusinessEntityID, person);
        }
    }
}
