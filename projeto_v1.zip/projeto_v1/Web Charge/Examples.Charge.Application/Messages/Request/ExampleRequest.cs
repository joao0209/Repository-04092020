﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Examples.Charge.Application.Messages.Request
{
    public class ExampleRequest
    {
        public string Nome { get; set; }
    }
}
