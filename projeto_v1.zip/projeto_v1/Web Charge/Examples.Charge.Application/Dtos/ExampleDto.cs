﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Examples.Charge.Application.Dtos
{
    public class ExampleDto
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
