﻿using Examples.Charge.Domain.Aggregates.PersonAggregate.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Examples.Charge.Domain.Aggregates.PersonAggregate
{
    public class PersonService : IPersonService
    {
        private readonly IPersonRepository _personRepository;
        public PersonService(IPersonRepository personRepository)
        {
            _personRepository = personRepository;

        }

        public async Task<List<Person>> FindAllAsync() => (await _personRepository.FindAllAsync()).ToList();
        public async Task<Person> FindByID(int id) => (await _personRepository.FindAllAsync()).ToList().Find(p => p.BusinessEntityID == id);

        public async Task<Person> PostPerson(string name)
        {
            return await _personRepository.AddPerson(name);
        }
    }
}
